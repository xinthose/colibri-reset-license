<?php
/* 
 *	Plugin Name: Colibri reset license
 *  Author: ExtendThemes
 *  Description: reset license
 *
 * License: GPLv3 or later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
 * Version: 1.0.0
 * Text Domain: colibri-page-builder
 */


delete_option('colibriwp_builder_license_key');
